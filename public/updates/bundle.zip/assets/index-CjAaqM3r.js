const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BSA7eS46.js","./index-CcZHHyeH.js","./index-BGO4s_SE.css"])))=>i.map(i=>d[i]);
import{J as t,_ as i}from"./index-CcZHHyeH.js";const o=t("LiveUpdate",{web:()=>i(()=>import("./web-BSA7eS46.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
