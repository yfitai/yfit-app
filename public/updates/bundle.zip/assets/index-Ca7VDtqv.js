const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-DtlVTvUL.js","./index-BfEsdyfa.js","./index-PYji06DM.css"])))=>i.map(i=>d[i]);
import{J as t,_ as i}from"./index-BfEsdyfa.js";const o=t("LiveUpdate",{web:()=>i(()=>import("./web-DtlVTvUL.js"),__vite__mapDeps([0,1,2]),import.meta.url).then(e=>new e.LiveUpdateWeb)});export{o as LiveUpdate};
